import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.ExecutorService;

public class Petrolero extends Barco implements Runnable {
	private int cantAgua;
	private int cantPetroleo;
	private ZonaDeCarga ZDC;

	public Petrolero(int id, int tipo, TorreDeControl tc, Puerta p, ZonaDeCarga zdc) {
		super(id, tipo, tc, p);
		this.ZDC = zdc;
		this.cantAgua = 0;
		this.cantPetroleo = 0;
		// TODO Auto-generated constructor stub
	}

	@Override
	public void run() {
		super.run();
		System.out.println("entrando barco petrolero " + super.getId() + " para recargar contenedores");
		ExecutorService result = Executors.newFixedThreadPool(2);

		try {
			this.ZDC.llegada(super.getId());
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		result.execute(new Runnable() {
			public void run() {
				while (cantPetroleo < 3000) {
					try {
						ZDC.RepostarPetroleo(getId());
					} catch (InterruptedException e) {
						e.printStackTrace();
					} catch (BrokenBarrierException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					cantPetroleo += 1000;

				}
				System.out.println("el barco " + getId() + " tiene " + cantPetroleo + " de gasoil");
			}
		});

		result.execute(new Runnable() {
			public void run() {
				while (cantAgua < 5000) {
					try {
						ZDC.RepostarAgua(getId());
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					cantAgua += 1000;

				}
				System.out.println("el barco " + getId() + " tiene " + cantAgua + " de agua");
			}
		});
		try {
			result.awaitTermination(5, TimeUnit.MILLISECONDS);
			super.setTipo(1);
			super.run();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		result.shutdown();
		

	}

}
