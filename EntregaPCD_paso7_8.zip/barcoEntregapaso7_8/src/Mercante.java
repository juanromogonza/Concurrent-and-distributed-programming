import java.util.ArrayList;
import java.util.Random;

public class Mercante extends Barco implements Runnable {
	ArrayList<Integer> cargamento;
	int contAz;
	int contHa;
	int contSa;
	private Plataforma Pla;
	

	public Mercante(int id, int tipo, TorreDeControl tc, Puerta p, Plataforma Pla) {
		super(id, tipo, tc, p);
		inicializarCargamento();
		this.Pla = Pla;

		// TODO Auto-generated constructor stub
	}

	private void inicializarCargamento() {
		this.cargamento = new ArrayList<Integer>();
		Random r = new Random();
		int aleatorio = -1;
		int i = 0;
		while (i < 37) {
			aleatorio = r.nextInt(3);
			if (contAz < 12 && aleatorio == 0) {
				this.cargamento.add(aleatorio);
				contAz++;
				i++;
			} else {
				if (contSa < 20 && aleatorio == 1) {
					this.cargamento.add(aleatorio);
					contSa++;
					i++;
				} else {
					if (contHa < 5 && aleatorio == 2) {
						this.cargamento.add(aleatorio);
						contHa++;
						i++;
					}
				}
			}
		}
	}

	public void run() {
		super.run();
		System.out.println("entrando barco mercante para descargar los contenedores");
		for (int i = 0; i < this.cargamento.size(); i++) {
			try {
				//System.out.println("HOLA");
				this.Pla.soltar(this.cargamento.get(i));
			} catch (InterruptedException e) {

			}
		}

	}

}
