import java.util.LinkedList;
import java.util.concurrent.Semaphore;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.CyclicBarrier;

public class ZonaDeCarga {

	CyclicBarrier contVacios;
	 CountDownLatch llegados ;
	private LinkedList<Contenedor> listaContenedores = new LinkedList<Contenedor>();
	Semaphore aguaOcupada = new Semaphore(1);

	public ZonaDeCarga(Contenedor c0, Contenedor c1, Contenedor c2, Contenedor c3, Contenedor c4) {
		this.listaContenedores.add(c0);
		this.listaContenedores.add(c1);
		this.listaContenedores.add(c2);
		this.listaContenedores.add(c3);
		this.listaContenedores.add(c4);
		this.contVacios = new CyclicBarrier(5);
		this.llegados = new CountDownLatch(5);
	}

	public void llegada(int id) throws InterruptedException {
		System.out.println(" el barco " + id + " espera a los demas");
		this.llegados.countDown();
		this.llegados.await();
	}

	public void RepostarPetroleo(int id) throws BrokenBarrierException, InterruptedException {

		if (this.listaContenedores.get(id).getCantidad() == 0) {
			System.out.println("el contenedor " + id + " espera a resopstar");
			this.contVacios.await();
			this.listaContenedores.get(id).recargar();
		}
		this.listaContenedores.get(id).vaciar();
		System.out.println("el barco " + id + " ha recargado 1000L de gasoil");
	}

	public void RepostarAgua(int id) throws InterruptedException {
		this.aguaOcupada.acquire();
		System.out.println("el barco " + id + " pide agua");
		System.out.println("el barco " + id + " recarga 1000 L de agua");
		System.out.println("el barco " + id + " le dan agua");
		this.aguaOcupada.release();
	}

}