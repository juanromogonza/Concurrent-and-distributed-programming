public class Puerta {

	public void Llegada(int id) {

		System.out.println("El barco " + id + " entra");
		System.out.println("El barco " + id + " entra");
		System.out.println("El barco " + id + " entra");

	}

	public void Salida(int id) {

		System.out.println("El barco " + id + " se va");
		System.out.println("El barco " + id + " se va");
		System.out.println("El barco " + id + " se va");

	}
}

