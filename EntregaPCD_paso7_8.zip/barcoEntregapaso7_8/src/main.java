import java.util.LinkedList;

public class main {
	public static void main(String[] args) {
		Puerta p = new Puerta();
		TorreDeControl tc = new TorreDeControl();
		LinkedList<Contenedor> contenedores = new LinkedList<Contenedor>();
		LinkedList<Petrolero> barcoPetrolero = new LinkedList<Petrolero>();
		LinkedList<Thread> listaThreads = new LinkedList<Thread>();
		LinkedList<Grua> listaGruas = new LinkedList<Grua>();
		Plataforma pla = new Plataforma();
		Barco mercante = new Mercante(5, 0, tc, p, pla);
		// creacion de las 3 gruas
		for (int i = 0; i < 3; i++) {
			listaGruas.add(new Grua(i, pla));
		}
		 //creacion de los 5 contenedores para el petroleo
		for (int i = 0; i < 5; i++) {
			contenedores.add(new Contenedor(false, i));
		}
		
		ZonaDeCarga ZDC = new ZonaDeCarga(contenedores.get(0), contenedores.get(1), contenedores.get(2),
				contenedores.get(3), contenedores.get(4));
		 //creacion de los 5 barcos petroleros
		for (int i = 0; i < 5; i++) {
			barcoPetrolero.add(new Petrolero(i, 0, tc, p, ZDC));
		}
		for (int i = 0; i < barcoPetrolero.size(); i++) {
			listaThreads.add(new Thread(barcoPetrolero.get(i)));
		}
		// creacion del thread del barco mercante
		listaThreads.add(new Thread(mercante));
		// creacion de los 10 barcos que entran
		for (int i = 6; i < 11; i++) {
			listaThreads.add(new Thread(new Barco(i, 0, tc, p)));
		}
		// creacion de los 10 barcos que salen
		for (int i = 16; i < 16; i++) {
			listaThreads.add(new Thread(new Barco(i, 1, tc, p)));
		}
		
		
		// start de todos los barcos
		for (int i = 0; i < listaThreads.size(); i++) {
			listaThreads.get(i).start();
		}
		// start de las gruas
		for (int i = 0; i < 3; i++) {
			listaGruas.get(i).start();
		}

	}
}
