
public class Grua extends Thread {

	int tipoGrua;
	int cantAz;
	int cantSa;
	int cantHa;
	private Plataforma Pla;

	public Grua(int tipo, Plataforma Pla) {
		this.tipoGrua = tipo;
		this.cantAz = 0;
		this.cantHa = 0;
		this.cantSa = 0;
		this.Pla = Pla;

	}

	public void run() {

		if (this.tipoGrua == 0) {
			while (this.cantAz < 12) {
				
					System.out.println("Grua 0 intenta coger 1 de azucar");
					try {
						this.Pla.coger(this.tipoGrua);
							this.cantAz++;
							System.out.println("La cantidad de contenedores de azucar cogidos es: "+this.cantAz);
						
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			System.out.println("Cantidad total de azucar recogida: "+this.cantAz);

		} else {
			if (this.tipoGrua == 1) {
				while (this.cantSa < 20) {
					try {
						System.out.println("Grua 1 intenta coger 1 de sal");
						this.Pla.coger(this.tipoGrua);
							this.cantSa++;
							System.out.println("La cantidad de contenedores de sal cogidos es: "+this.cantSa);
						
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				System.out.println("Cantidad total de sal recogida: "+this.cantSa);

			} else {
				while (this.cantHa < 5) {
					try {
						System.out.println("Grua 2 intenta coger 1 de harina");
						this.Pla.coger(this.tipoGrua);
							this.cantHa++;
							System.out.println("La cantidad de contenedores de harina cogidos es: "+this.cantHa);
						
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
				}
				System.out.println("Cantidad total de harina recogida: "+this.cantHa);

			}
		}

		System.out.println("ha acabado la grua " + this.tipoGrua);

	}

}