
public class Contenedor {
	private boolean esAgua;
	private int tipoBarco;
	private int cantidad;

	public Contenedor(boolean esAgua, int tipoBarco) {
		this.esAgua = esAgua;
		this.tipoBarco = tipoBarco;
		if (this.esAgua) {
			this.cantidad = -1;
		} else {
			this.cantidad = 1000;
		}
	}

	public int getCantidad() {
		return this.cantidad;
	}

	public void vaciar() {
		this.cantidad = 0;
	}

	public void recargar() {
		this.cantidad = 1000;
	}

	public int darAgua() {
		return 1000;
	}

	public int getId() {
		return this.tipoBarco;
	}
}
