
public class Barco implements Runnable {
	private int id;
	private int tipo;
	TorreDeControl tc;
	Puerta p;

	public Barco(int id, int tipo, TorreDeControl tc, Puerta p) {
		this.id = id;
		this.tipo = tipo;
		this.tc = tc;
		this.p = p;
	}

	public int getId() {
		return this.id;
	}

	public void setTipo(int i) {
		this.tipo = i;
	}

	public void superRun() {
		run();
	}

	@Override
	public void run() {
		// otro if pa saber si es mercante

		if (tipo == 0) {

			tc.permisoEntrada(id);
			p.Llegada(id);

			tc.finEntrada(id);
		} else {
			tc.permisoSalida(id);
			p.Salida(id);
			tc.finSalida(id);
		}

	}
}
