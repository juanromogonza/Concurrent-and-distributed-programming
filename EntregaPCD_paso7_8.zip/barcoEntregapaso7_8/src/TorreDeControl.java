public class TorreDeControl {
	int entrando;
	int saliendo;
	boolean flag;

	public TorreDeControl() {
		this.entrando = 0;
		this.saliendo = 0;
		this.flag = false;
	}

	synchronized public void permisoEntrada(int tipo) {
		System.out.println("pide permiso para entrar el barco" + tipo);
		while (saliendo > 0 || flag) {
			try {

				System.out.println("se bloquea el barco " + tipo);
				wait();

			} catch (InterruptedException e) {

			}
		}
		entrando++;
	}

	synchronized public void permisoSalida(int tipo) {
		System.out.println("pide permiso para salir el barco" + tipo);
		while (entrando > 0) {
			try {
				flag = true;
				System.out.println("se bloquea el barco " + tipo);
				wait();

			} catch (InterruptedException e) {

			}
		}
		saliendo++;
	}

	synchronized public void finEntrada(int tipo) {
		entrando--;
		System.out.println("entra el barco " + tipo);
		if (entrando == 0) {

			notifyAll();
		}

	}

	synchronized public void finSalida(int tipo) {
		saliendo--;
		System.out.println("sale el barco " + tipo);
		if (saliendo == 0) {
			flag = false;
			notifyAll();
		}

	}

}