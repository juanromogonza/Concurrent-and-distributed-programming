
import java.util.LinkedList;
import java.util.concurrent.SynchronousQueue;

public class Plataforma extends Thread {

	private LinkedList<SynchronousQueue<Integer>> gruas = new LinkedList<SynchronousQueue<Integer>>();
	SynchronousQueue<Integer> colaElementos;
	SynchronousQueue<Integer> gruaSal;
	SynchronousQueue<Integer> gruaAzucar;
	SynchronousQueue<Integer> gruaHarina;

	public Plataforma() {
		this.colaElementos = new SynchronousQueue<Integer>();
		this.gruaSal = new SynchronousQueue<Integer>();
		this.gruaAzucar = new SynchronousQueue<Integer>();
		this.gruaHarina = new SynchronousQueue<Integer>();
		this.gruas.add(gruaAzucar);
		this.gruas.add(gruaSal);
		this.gruas.add(gruaHarina);

	}

	public void soltar(int carga) throws InterruptedException {

		System.out.println("Soltando la carga " + carga);
		this.gruas.get(carga).put(carga);
		this.colaElementos.put(carga);
	}

	public void coger(int id) throws InterruptedException {

		this.gruas.get(id).take();
		System.out.println("Grua " + id + " ha cogido la carga de tipo " + id);
		this.colaElementos.take();

	}
}